package edu.uwm.apc430;

import java.util.*;
import java.io.*;

public class Bid {
    private final double price;
    private final String bidder;

    public Bid(String bidder, double price) {
        this.bidder = bidder;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public String getBidder() {
        return bidder;
    }

    public static Bid fromString(String input) throws NumberFormatException {
        input = input.trim();
        int spaceIndex = input.indexOf(" ");

        if (spaceIndex == -1) {
            throw new NumberFormatException("Invalid bid format: missing bidder name");
        }

        String pricePart = input.substring(0, spaceIndex).trim();
        String bidderPart = input.substring(spaceIndex).trim();

        if (bidderPart.isEmpty()) {
            throw new NumberFormatException("Invalid bid format: bidder name missing");
        }

        double price;
        try {
            price = Double.parseDouble(pricePart);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Invalid bid format: price must be a number");
        }

        return new Bid(bidderPart, price);
    }

    public static Bid[] readBids(Scanner scanner, PrintWriter out) {
        ArrayList<Bid> bids = new ArrayList<>();
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) {
                continue;
            }
            try {
                bids.add(fromString(line));
            } catch (NumberFormatException e) {
                out.println("Error: " + e.getMessage());
            }
        }
        return bids.toArray(new Bid[0]);
    }
}