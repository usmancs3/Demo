package edu.uwm.apc430;

import java.util.*;
import java.io.*;

public class VickreyAuction {
    public static void run(Scanner scanner, PrintWriter out) {
        Bid[] bids = Bid.readBids(scanner, out);
        if (bids.length < 2) {
            out.println("Not enough bids to determine a winner.");
            return;
        }

        Arrays.sort(bids, (a, b) -> Double.compare(b.getPrice(), a.getPrice()));
        Bid winner = bids[0];
        double priceToPay = bids.length > 1 ? bids[1].getPrice() : winner.getPrice();

        out.println("Winner: " + winner.getBidder());
        out.println("Price: " + priceToPay);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out, true);
        run(scanner, out);
    }
}
